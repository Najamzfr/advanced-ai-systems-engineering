"""Local evidence checker."""
