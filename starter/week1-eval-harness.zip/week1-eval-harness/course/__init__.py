"""Local, deterministic course checker."""
