"""Deterministic weekly project checker."""
